import pygame, Global, random, copy
from Utils.UiComponents.TextLabel import TextLabel
from Utils.UiComponents.Box import Box
from Utils.Game.mathStuff import Timer
from Services.mapService import create_map, handle_click, map_update, mapLock, mapUnLock

class SimpleSprite(pygame.sprite.Sprite):
    def __init__(
        self,
        pos: pygame.Vector2,
        size: pygame.Vector2,
        groups=None,
        imagePath: str = None,
        color: tuple = (255, 255, 255, 255),
        layer: int = 0,
    ):
        super().__init__()
        if groups is not None:
            if isinstance(groups, (list, tuple)):
                for g in groups:
                    g.add(self, layer=layer)
            else:
                groups.add(self, layer=layer)

        self.pos  = pygame.Vector2(pos)
        self.size = pygame.Vector2(size)
        self.image = Global.loadImage(imagePath, (int(size.x), int(size.y)))
        self.rect = self.image.get_rect(center=self.pos)

    def move(self, direction: pygame.Vector2, speed: float, dt: float = None):
        dt = dt or Global.mainBackGroundDt
        if direction.length() == 0:
            return
        self.pos += direction.normalize() * speed * dt
        self.rect.center = self.pos

    def moveTo(self, destination: pygame.Vector2, speed: float, dt: float = None):
        dt    = dt or Global.mainBackGroundDt
        delta = pygame.Vector2(destination) - self.pos
        dist  = delta.length()
        step  = speed * dt
        if dist <= step:
            self.pos = pygame.Vector2(destination)
        else:
            self.pos += delta.normalize() * step
        self.rect.center = self.pos

    def setPos(self, pos: pygame.Vector2):
        self.pos = pygame.Vector2(pos)
        self.rect.center = self.pos

    def update(self):
        self.move(pygame.Vector2(-1, 0), speed=200, dt=Global.mainBackGroundDt)
        if (
            self.pos[0] < -200 or
            self.pos[0] > Global.mainGameBox.size.x + 200 or
            self.pos[1] < -200 or
            self.pos[1] > Global.mainGameBox.size.y + 200
        ):
            self.kill()
       # Global.mainGameBox.canvas.blit(self.image, self.rect)

from Classes.Enemies.SpikeEnemy import SpikeEnemy
from Classes.Enemies.LaserEnemy import LaserEnemy
from Classes.Enemies.ClownEnemy import ClownEnemy
from Classes.Enemies.MinigunEnemy import MinigunEnemy
from Classes.Enemies.Monki import Monki
ENEMY_REGISTRY = {
    "SpikeEnemy": SpikeEnemy,
    "LaserEnemy": LaserEnemy,
    "ClownEnemy": ClownEnemy,
    "MinigunEnemy": MinigunEnemy,
    "Monki" : Monki,
}

class mainGameService:
    def __init__(self):
        self.bgSpawnCD = (0.5,1)
        self.bgCurrentSpawn = 0 
        Global.mainBackGroundDt = Global.dt
        self.shopSprite = None # on main game box
        #self.shop = Global.UiService.spawnShop()
        self.mapHidden = False
        self.shop = None
        #groundBox
        currSize = pygame.Vector2(750,700)
        ground = Box(
            pos=pygame.Vector2(0,175),
            size=currSize,
            groups=Global.mainBackGroundGroup,
            color=(245, 245, 245, 255),
            border=True,
            borderColor=(100, 100, 100, 255),
            borderWidth=5,
            borderRadius=0,
        )
        Global.mainBackGroundGroup.add(ground)
        self.create_and_position_map()

        self.mouseHB = Global.hitbox.new(
            pos=pygame.Vector2(pygame.mouse.get_pos()),
            visualize=False,
            size=pygame.Vector2(25,25),
            lifetime=None,
            hitFunction=None,
            owner=pygame.mouse,
        )
        Global.saveManager.saveCheckpoint() # initial save
        self.isReverting = False

        Global.SoundManager.musicVolume = 0.3
        Global.SoundManager.setPlaylist([
            "Assets/Sounds/Music/love_shuttle.mp3",
            "Assets/Sounds/Music/ready_or_not.mp3",
        ])
        Global.SoundManager.pausePlaylist()

    def create_and_position_map(self):
        mapSize = (random.randint(8,15), random.randint(8,15))
        tileSize = (50,50)
        offset = 2
        boxRect = Global.minesweeperBox.rect
        mapPos = (
            boxRect.x + (boxRect.width- (mapSize[0] * (tileSize[0] + offset) - offset)) / 2  + tileSize[0] / 2,
            boxRect.y + (boxRect.height - (mapSize[1] * (tileSize[1] + offset) - offset)) / 2  + tileSize[1] / 2,
        )
        Global.currentMap = create_map(
            cols=mapSize[0],
            rows=mapSize[1],
            offset=offset,
            color=(100,100,100,255),
            hiddenColor=(50,50,50,255),
            revealColor=(200,200,200,255),
            bombColor=(255,50,50,255),
            flagColor=(220,220,0),
            mapPos=mapPos,
            tileSize=tileSize,
            bombCount=int((mapSize[0] * mapSize[1]) * 0.1)
        )

    def stop(self,stop: bool):
        if stop:
            self.dt = 0

    def handleEvent(self, event):
        if event.type == pygame.MOUSEBUTTONUP and event.button == 1 and Global.minesweeperBox.rect.collidepoint(pygame.mouse.get_pos()) and Global.gameState == "Playing":
            self.mapHidden = False
            Global.UiService.revealMap()

    def playerDie(self):
        self.create_and_position_map()

        for sprite in list(Global.entityGroup):
            if sprite != Global.playerSprite:
                sprite.kill()

        for sprite in list(Global.msAttackGroup):
            sprite.kill()
        Global.msParticleGroup.empty()
        Global.timerGroup.empty()

        Global.saveManager.revertToCheckpoint()

        Global.playerStats["HP"] = Global.playerStats["MaxHP"]

        gameProgress = Global.gameProgress[Global.currentDifficulty]
        self.currentEnemies = copy.deepcopy(gameProgress[f"Round{Global.currentRound}"])
        self.enemyLastSpawn = 2

        self.shop = None
        self.shopSprite = None
        Global.gameState = "Buying"

        self.isReverting = True

            
    def update(self):
        if Global.gameState == "Playing":
            Global.mainBackGroundDt = Global.dt

        self.bgCurrentSpawn -= Global.mainBackGroundDt
        if self.bgCurrentSpawn <= 0: 
            randomSize = random.randint(150,250)
            SimpleSprite(
                pos=pygame.Vector2(900, 100 - (randomSize/2 - 100)),
                size=pygame.Vector2(randomSize,randomSize),
                groups=Global.mainBackGroundGroup,
                imagePath=random.choice(["Assets/Background/house1.png", "Assets/Background/tree.png"]),
            )
            self.bgCurrentSpawn = random.uniform(self.bgSpawnCD[0], self.bgSpawnCD[1])
        
        map_update(Global.currentMap)

        #|----------------------------Game Loop----------------------------|
        Global.dt = Global.tick * Global.speedupMultiplier
        
        if (not Global.minesweeperBox.rect.collidepoint(pygame.mouse.get_pos()) and Global.gameState == "Playing") or self.mapHidden:
            Global.dt = 0
            if not self.mapHidden:
                Global.UiService.hideMap()
            self.mapHidden = True
        else:
            Global.UiService.revealMap()
            self.mapHidden = False            

        if Global.gameState == "Preparing":
            Global.SoundManager.resumePlaylist()
            Global.saveManager.saveCheckpoint()
            gameProgress = Global.gameProgress[Global.currentDifficulty]
            self.enemyLastSpawn = 2
            self.currentEnemies = copy.deepcopy(gameProgress[f"Round{Global.currentRound}"])
            self.currentEnemies = {
                k: v for k, v in self.currentEnemies.items() if isinstance(v, dict)
            }
            Global.playerStats["HP"] = Global.playerStats["MaxHP"]
            self.shopSprite = None

            spawnRate = gameProgress[f"Round{Global.currentRound}"].get("SpawnRate", None)
            self.enemySpawnCD = spawnRate if spawnRate else gameProgress["SpawnRate"]
            burstSpawnRate = gameProgress[f"Round{Global.currentRound}"].get("SpawnBurst", None)
            self.enemySpawnBurst = burstSpawnRate if burstSpawnRate else gameProgress["SpawnBurst"]

            Global.currentRarity = Global.updateRarity(Global.currentRound)
            print(Global.currentRarity)

            Global.gameState = "Playing"

        if Global.gameState == "Playing":
            if Global.playerStats["HP"] <= 0:
                Global.SoundManager.stopMusic()
                Global.SoundManager.pausePlaylist()
                from Utils.UiComponents.GameOver import GameOver
                GameOver(groups=Global.uiGroup, onDone=self.playerDie, duration=2)
                Global.gameState = "Died"

            self.mouseHB.pos = pygame.Vector2(pygame.mouse.get_pos()) if not self.mapHidden else pygame.Vector2(-200,-200)
            self.enemyLastSpawn -= Global.mainBackGroundDt

            # Enemy left check
            enemyLeft = [k for k, v in self.currentEnemies.items() if v.get("InGame", 0) > 0 or v["EnemyLeft"] > 0]

            if not enemyLeft:
                Global.gameState = "Shop"
                self.mouseHB.pos = pygame.Vector2(-200,-200)

            # spawn Enemies
            if self.enemyLastSpawn <= 0:
                self.enemyLastSpawn = random.uniform(self.enemySpawnCD[0], self.enemySpawnCD[1])

                def spawnEnemy():
                    available = [k for k, v in self.currentEnemies.items() 
                    if v.get("InGame", 0) < v["MaxEnemy"] and v["EnemyLeft"] > 0]

                    if not available:
                        return  # all at max, skip this spawn tick

                    chosenEnemy = random.choice(available)
                    enemyData   = self.currentEnemies[chosenEnemy]

                    if "InGame" not in enemyData:
                        enemyData["InGame"] = 0

                    if chosenEnemy == "Monki":
                        newEnemy = ENEMY_REGISTRY[chosenEnemy](
                            pos=pygame.Vector2(550, 300),
                            size=pygame.Vector2(400, 400),
                            groups=Global.entityGroup,
                        )
                        Global.entityGroup.add(newEnemy)
                    else:
                        newEnemy = ENEMY_REGISTRY[chosenEnemy](
                            pos=pygame.Vector2(random.randint(450, 650), random.randint(100, 450)),
                            size=pygame.Vector2(200, 200),
                            groups=Global.entityGroup,
                        )
                        Global.entityGroup.add(newEnemy)

                    enemyData["InGame"]   += 1
                    enemyData["EnemyLeft"] -= 1

                    def removal():
                        enemyData["InGame"] -= 1
                    newEnemy.dieFunction = removal

                for i in range(random.randint(self.enemySpawnBurst[0], self.enemySpawnBurst[1])):
                    Timer(random.uniform(0.5, 1.5) * i, spawnEnemy, Global.timerGroup)

            if Global.currentMap["completed"]:
                self.create_and_position_map()

        if Global.gameState == "Shop":
            #Global.currentRound += 1
            if not self.shopSprite:
                Global.SoundManager.pausePlaylist()
                Global.SoundManager.playMusic("Assets/Sounds/Music/shop.mp3")

                self.shopSprite = SimpleSprite(
                    pos=pygame.Vector2(900, 150),
                    size=pygame.Vector2(200,200),
                    groups=Global.mainBackGroundGroup,
                    imagePath="Assets/Background/shop.png",
                    layer=999,
                )
            
            if self.shopSprite.pos.x <= 400:
                Global.mainBackGroundDt = 0
                Global.gameState = "Buying"
                self.shop = None
            else:
                Global.mainBackGroundDt = Global.dt
        if Global.gameState == "Buying":
            if not self.shop:
                for sprite in list(Global.msAttackGroup):
                    sprite.kill()
                Global.msParticleGroup.empty()
                mapLock(Global.currentMap)
                self.shop = Global.UiService.spawnShop()

            if self.shop.removed:
                mapUnLock(Global.currentMap)
                if self.isReverting: 
                    self.isReverting = False
                else:
                    Global.currentRound += 1

                Global.SoundManager.stopMusic()
                Global.SoundManager.resumePlaylist()
                Global.gameState = "Preparing"
        if Global.gameState == "Win":
            Global.SoundManager.stopMusic()
            Global.SoundManager.pausePlaylist()
            for i in range(3):
                def yip():
                    Global.SoundManager.playSFX("Assets/Sounds/SoundEffect/yippe.mp3", 1)
                Timer(i*0.5, yip, Global.timerGroup)
            def resetBack():
                Global.saveManager.deleteSave()
                Global.saveManager.resetToDefault()  

                self.create_and_position_map()
                for sprite in list(Global.entityGroup):
                    if sprite != Global.playerSprite:
                        sprite.kill()
                for sprite in list(Global.msAttackGroup):
                    sprite.kill()
                Global.msParticleGroup.empty()
                Global.timerGroup.empty()

                self.shop = None
                self.shopSprite = None
                self.mapHidden = False

                Global.gameState = "Menu"
                from Utils.UiComponents.MainMenu import MainMenu
                Global.mainMenu = MainMenu()
            from Utils.UiComponents.Win import Win
            Win(groups=Global.uiGroup, onDone=resetBack, duration=3)
            print(Global.gameState)
            Global.gameState = "WinProceeded"