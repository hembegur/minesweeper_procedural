import pygame, Global
from random import randint


class Particle(pygame.sprite.Sprite):
    def __init__(self,
        groups: pygame.sprite.Group,
        pos: list[int],
        color: str,
        direction: pygame.math.Vector2,
        speed: int,
        size: int,
        fadeSpeed: int = 200):
        super().__init__(groups)
        self.pos = pos
        self.color = color
        self.direction = direction
        self.speed = speed
        self.alpha = 255
        self.fade_speed = fadeSpeed
        self.size = size

        self.create_surf()

    def create_surf(self):
        self.image = pygame.Surface((self.size, self.size), pygame.SRCALPHA)
        # alpha baked into color as 4th value
        pygame.draw.circle(
            surface=self.image,
            color=(*self.color, int(self.alpha)),
            center=(self.size / 2, self.size / 2),
            radius=self.size / 2
        )
        self.rect = self.image.get_rect(center=self.pos)
        # self.image = pygame.Surface((self.size, self.size)).convert_alpha()
        # self.image.set_colorkey("black")
        # pygame.draw.circle(surface=self.image, color=self.color, center=(self.size / 2, self.size / 2), radius=self.size / 2)
        # self.rect = self.image.get_rect(center=self.pos)

    def move(self, dt):
        self.pos += self.direction * self.speed * dt
        self.rect.center = self.pos

    def fade(self, dt):
        self.alpha -= self.fade_speed * dt
        self.alpha = max(0, self.alpha)
        # Clear and redraw with new alpha — never use set_alpha() on SRCALPHA surfaces
        self.image.fill((0, 0, 0, 0))
        pygame.draw.circle(
            surface=self.image,
            color=(*self.color, int(self.alpha)),
            center=(self.size / 2, self.size / 2),
            radius=self.size / 2
        )
        # self.alpha -= self.fade_speed * dt
        # self.image.set_alpha(self.alpha)

    def check_pos(self):
        if (
            self.pos[0] < -50 or
            self.pos[0] > Global.screenWidth + 50 or
            self.pos[1] < -50 or
            self.pos[1] > Global.screenHeight + 50
        ):
            self.kill()

    def check_alpha(self):
        if self.alpha <= 0:
            self.kill()

    def update(self):
        self.move(Global.dt)
        self.fade(Global.dt)
        self.check_pos()
        self.check_alpha()

class ImageParticle(pygame.sprite.Sprite):
    def __init__(self,
        groups,
        pos,
        imagePath: str,
        direction: pygame.math.Vector2,
        speed: int,
        size: int,
        fadeSpeed: int = 200,
        shrinkSpeed: float = 0,   # shrink size per second, 0 = no shrink
        rotation: float = 0,      # rotation speed in degrees per second
        lifetime: float = None,
    ):
        super().__init__(groups)
        self.pos        = pygame.Vector2(pos)
        self.direction  = direction
        self.speed      = speed
        self.alpha      = 255
        self.fadeSpeed  = fadeSpeed
        self.size       = float(size)
        self.shrinkSpeed = shrinkSpeed
        self.angle      = 0
        self.rotation   = rotation
        self.imagePath  = imagePath
        self._lifetime = lifetime

        self.ogImage = Global.loadImage(imagePath, (int(size), int(size)))
        self.image   = self.ogImage.copy()
        self.rect    = self.image.get_rect(center=self.pos)

    def _rebuild(self):
        s = max(1, int(self.size))
        scaled = pygame.transform.scale(self.ogImage, (s, s))
        if self.rotation != 0:
            self.image = pygame.transform.rotate(scaled, self.angle)
        else:
            self.image = scaled
        self.image.set_alpha(int(self.alpha))
        self.rect = self.image.get_rect(center=self.pos)

    def update(self):
        dt = Global.dt

        if self._lifetime is not None:
            self._lifetime -= Global.dt
            if self._lifetime <= 0:
                self.kill()
        # move
        self.pos += self.direction * self.speed * dt
        self.rect.center = self.pos

        # fade
        self.alpha = max(0, self.alpha - self.fadeSpeed * dt)

        # shrink
        if self.shrinkSpeed > 0:
            self.size = max(1, self.size - self.shrinkSpeed * dt)

        # rotate
        if self.rotation != 0:
            self.angle += self.rotation * dt

        self._rebuild()

        # kill checks
        if self.alpha <= 0 or self.size <= 1:
            self.kill()
        if (
            self.pos.x < -50 or self.pos.x > Global.screenWidth + 50 or
            self.pos.y < -50 or self.pos.y > Global.screenHeight + 50
        ):
            self.kill()


class ExplodingParticle(Particle):
    def __init__(self,
                 groups: pygame.sprite.Group,
                 pos: list[int],
                 color: str,
                 direction: pygame.math.Vector2,
                 speed: int):
        super().__init__(groups, pos, color, direction, speed)
        self.t0 = pygame.time.get_ticks()
        self.lifetime = randint(1000, 1200)
        self.exploding = False
        self.size = 4
        self.max_size = 50
        self.inflate_speed = 500
        self.fade_speed = 3000

    def explosion_timer(self):
        if not self.exploding:
            t = pygame.time.get_ticks()
            if t - self.t0 > self.lifetime:
                self.exploding = True

    def inflate(self, dt):
        self.size += self.inflate_speed * dt
        self.create_surf()

    def check_size(self):
        if self.size > self.max_size:
            self.kill()

    def update(self, dt):
        self.move(dt)
        self.explosion_timer()
        if self.exploding:
            self.inflate(dt)
            self.fade(dt)

        self.check_pos()
        self.check_size()
        self.check_alpha()


class FloatingParticle(Particle):
    def __init__(self,
                 groups: pygame.sprite.Group,
                 pos: list[int],
                 color: str,
                 direction: pygame.math.Vector2,
                 speed: int):
        super().__init__(groups, pos, color, direction, speed)